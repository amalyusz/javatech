import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.awt.Graphics;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;



public class TorpedoTest{		

	public static void main(String[] args) {		
		
		Windows window = new Windows();
		window.show();
	}
}